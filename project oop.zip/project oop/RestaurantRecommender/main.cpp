#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <limits>
#include <iomanip>
#include <algorithm>
#include <ranges>
#include <cctype>

using namespace std;

class Node {
public:
    explicit Node(const string& data) : data(data), next(nullptr) {}

    string getData() const {
        return data;
    }

    void setData(const string& data) {
        this->data = data;
    }

    Node* getNext() const {
        return next;
    }

    void setNext(Node* next) {
        this->next = next;
    }

private:
    string data;
    Node* next;
};

class Restaurant {
public:
    Restaurant() : details(nullptr) {}

    const string& getName() const {
        return name;
    }

    void setName(const string& name) {
        this->name = name;
    }

    const string& getCuisine() const {
        return cuisine;
    }

    void setCuisine(const string& cuisine) {
        this->cuisine = cuisine;
    }

    double getRating() const {
        return rating;
    }

    void setRating(double rating) {
        this->rating = rating;
    }

    const string& getArea() const {
        return area;
    }

    void setArea(const string& area) {
        this->area = area;
    }

    const string& getPriceRating() const {
        return priceRating;
    }

    void setPriceRating(const string& priceRating) {
        this->priceRating = priceRating;
    }

    Node* getDetails() const {
        return details;
    }

    void setDetails(Node* details) {
        this->details = details;
    }

private:
    string name;
    string cuisine;
    double rating;
    string area;
    string priceRating; // price rating: $, $$, $$$, $$$$
    Node* details; // Pointer to linked list for additional details
};

string toLower(const string& str) {
    string lowerStr = str;
    ranges::transform(lowerStr, lowerStr.begin(), ::tolower);
    return lowerStr;
}

class RestaurantRecommender {
public:
    RestaurantRecommender(const string& cuisine, double rating, const string& area, const string& price)
        : preferredCuisine(toLower(cuisine)), minRating(rating), preferredArea(toLower(area)), preferredPriceRating(price) {}

    void operator()(vector<Restaurant>& restaurants) const {
        vector<Restaurant> filteredRestaurants;
        for (const auto& restaurant : restaurants) {
            if ((preferredCuisine.empty() || toLower(restaurant.getCuisine()) == preferredCuisine) &&
                restaurant.getRating() >= minRating &&
                (preferredArea.empty() || toLower(restaurant.getArea()) == preferredArea) &&
                (preferredPriceRating.empty() || priceValue(restaurant.getPriceRating()) <= priceValue(preferredPriceRating))) {
                filteredRestaurants.push_back(restaurant);
            }
        }

        if (filteredRestaurants.empty()) {
            cout << "No restaurants found matching your preferences." << endl;
            return;
        }

        for (size_t i = 0; i < filteredRestaurants.size(); ++i) {
            const auto& restaurant = filteredRestaurants[i];
            cout << setw(3) << setfill('0') << i << ": "
                 << "Name: " << restaurant.getName()
                 << ", Cuisine: " << restaurant.getCuisine()
                 << ", Rating: " << restaurant.getRating()
                 << ", Area: " << restaurant.getArea()
                 << ", Price: " << restaurant.getPriceRating() << endl;
        }

        char sortChoice;
        cout << "Do you want to sort the list? (y/n): ";
        cin >> sortChoice;
        if (sortChoice == 'y' || sortChoice == 'Y') {
            int sortOption;
            cout << "Enter 1 to sort by ascending price or 2 to sort by descending rating: ";
            while (!(cin >> sortOption) || (sortOption != 1 && sortOption != 2)) {
                cout << "Invalid option. Enter 1 to sort by ascending price or 2 to sort by descending rating: ";
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
            }

            if (sortOption == 1) {
                ranges::sort(filteredRestaurants, {}, [](const Restaurant& r) { return priceValue(r.getPriceRating()); });
            } else if (sortOption == 2) {
                ranges::sort(filteredRestaurants, {}, [](const Restaurant& r) { return -r.getRating(); });
            }

            for (size_t i = 0; i < filteredRestaurants.size(); ++i) {
                const auto& restaurant = filteredRestaurants[i];
                cout << setw(3) << setfill('0') << i << ": "
                     << "Name: " << restaurant.getName()
                     << ", Cuisine: " << restaurant.getCuisine()
                     << ", Rating: " << restaurant.getRating()
                     << ", Area: " << restaurant.getArea()
                     << ", Price: " << restaurant.getPriceRating() << endl;
            }
        }

        while (true) {
            int serialChoice;
            cout << "Enter the serial number of the restaurant to view details, or -1 to go back: ";
            cin >> serialChoice;
            if (serialChoice == -1) break;
            if (serialChoice >= 0 && serialChoice < static_cast<int>(filteredRestaurants.size())) {
                displayRestaurantDetails(filteredRestaurants[serialChoice]);
            } else {
                cout << "Invalid serial number. Please try again." << endl;
            }
        }
    }

private:
    string preferredCuisine;
    double minRating;
    string preferredArea;
    string preferredPriceRating;

    static int priceValue(const string& priceRating) {
        if (priceRating == "$") return 1;
        if (priceRating == "$$") return 2;
        if (priceRating == "$$$") return 3;
        if (priceRating == "$$$$") return 4;
        return 0;
    }

    void displayRestaurantDetails(const Restaurant& restaurant) const {
        cout << "Details of " << restaurant.getName() << ":" << endl;
        Node* current = restaurant.getDetails();
        if (current) {
            cout << "    Address: " << current->getData() << endl;
            current = current->getNext();
        }
        if (current) {
            cout << "    Type: " << current->getData() << endl;
            current = current->getNext();
        }
        if (current) {
            cout << "    Discounts: " << current->getData() << endl;
            current = current->getNext();
        }
        if (current) {
            cout << "    Menu: " << current->getData() << endl;
        }
    }
};

void loadRestaurants(vector<Restaurant>& restaurants, const string& filename) {
    ifstream file(filename);

    if (!file) {
        cerr << "Error: Could not open file " << filename << endl;
        return;
    }

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        Restaurant restaurant;
        string name, cuisine, area, priceRating;
        double rating;
        ss >> quoted(name) >> quoted(cuisine) >> rating >> quoted(area) >> quoted(priceRating);
        restaurant.setName(name);
        restaurant.setCuisine(cuisine);
        restaurant.setRating(rating);
        restaurant.setArea(area);
        restaurant.setPriceRating(priceRating);
        restaurants.push_back(restaurant);
    }
}

void loadRestaurantDetails(Restaurant& restaurant, const string& line) {
    stringstream ss(line);
    string name, address, type, discounts, menu;
    if (ss >>quoted(name) >> quoted(address) >> quoted(type) >> quoted(discounts) >> quoted(menu)) {
        Node* addressNode = new Node(address);
        Node* typeNode = new Node(type);
        Node* discountsNode = new Node(discounts);
        Node* menuNode = new Node(menu);

        addressNode->setNext(typeNode);
        typeNode->setNext(discountsNode);
        discountsNode->setNext(menuNode);

        restaurant.setDetails(addressNode);
    }
}

void loadAllRestaurantDetails(vector<Restaurant>& restaurants, const string& filename) {
    ifstream file(filename);

    if (!file) {
        cerr << "Error: Could not open file " << filename << endl;
        return;
    }

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        string name;
        if (ss >> quoted(name)) {
            auto it = find_if(restaurants.begin(), restaurants.end(), [&name](const Restaurant& r) {
                return toLower(r.getName()) == toLower(name);
            });
            if (it != restaurants.end()) {
                loadRestaurantDetails(*it, line);
            }
        }
    }
}

int main() {
    vector<Restaurant> restaurants;
    string restaurantsFilename = "restaurants.txt";
    string detailsFilename = "details.txt";

    loadRestaurants(restaurants, restaurantsFilename);
    loadAllRestaurantDetails(restaurants, detailsFilename);

    while (true) {
        string cuisine, area, priceRating;
        double rating;

        cout << "Enter preferred cuisine (or leave empty for any): ";
        cin.ignore();
        getline(cin, cuisine);
        cout << "Enter minimum rating (or 0 for any): ";
        cin >> rating;
        cout << "Enter preferred area (or leave empty for any): ";
        cin.ignore();
        getline(cin, area);
        cout << "Enter preferred price rating (or leave empty for any): ";
        getline(cin, priceRating);
        RestaurantRecommender recommender(cuisine, rating, area, priceRating);
        recommender(restaurants);

        char continueChoice;
        cout << "Do you want to search again? (y/n): ";
        cin >> continueChoice;
        if (continueChoice == 'n' || continueChoice == 'N') {
            break;
        }
    }

    return 0;
}