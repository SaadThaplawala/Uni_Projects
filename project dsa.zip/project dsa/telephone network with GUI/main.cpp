#include <SFML/Graphics.hpp>
#include <iostream>
#include <climits>
#include <limits>
#include <cstring>

using namespace std;

struct Node {
    int dest;
    int bandwidth;
    Node* next;
    Node(int d, int b){
        dest = d;
        bandwidth = b;
        next = nullptr;
    }
};

class LinkedList {
public:
    Node* head;
    LinkedList(){
        head = nullptr;
    }
    void addEdge(int dest, int bandwidth) {
        Node* newNode = new Node(dest, bandwidth);
        newNode->next = head;
        head = newNode;
    }
};

struct StackNode {
    int data;
    StackNode* next;
    StackNode(int d){
        data = d;
        next = nullptr;
    }
};

class Stack {
private:
    StackNode* top;

public:
    Stack(){
        top = nullptr;
    }
    void push(int data) {
        StackNode* newNode = new StackNode(data);
        newNode->next = top;
        top = newNode;
    }

    int pop() {
        if (isEmpty()) {
            return -1;
        }
        int data = top->data;
        StackNode* temp = top;
        top = top->next;
        delete temp;
        return data;
    }

    bool isEmpty() {
        return top == nullptr;
    }
};

struct QueueNode {
    int data;
    QueueNode* next;
    QueueNode(int d){
        data = d;
        next = nullptr;
    }
};

class Queue {
private:
    QueueNode *front, *rear;

public:
    Queue(){
        front = nullptr;
        rear = nullptr;
    }
    void enqueue(int data) {
        QueueNode* newNode = new QueueNode(data);
        if (rear) {
            rear->next = newNode;
        }
        rear = newNode;
        if (!front) {
            front = rear;
        }
    }

    int dequeue() {
        if (isEmpty()) {
            return -1;
        }
        int data = front->data;
        QueueNode* temp = front;
        front = front->next;
        if (!front) {
            rear = nullptr;
        }
        delete temp;
        return data;
    }

    bool isEmpty() {
        return front == nullptr;
    }
};

class Graph {
private:
    int V;
    LinkedList* adj;

public:
    Graph(int V) {
        this->V = V;
        adj = new LinkedList[V];
    }

    ~Graph() {
        delete[] adj;
    }

    void addEdge(int u, int v, int bandwidth) {
        // Adjust for 1-based index
        if (u >= 1 && u <= V && v >= 1 && v <= V) {
            adj[u-1].addEdge(v-1, bandwidth);
            adj[v-1].addEdge(u-1, bandwidth);
        } else {
            cout << "Invalid edge (" << u << ", " << v << ")!" << endl;
        }
    }
    void DFS(int start) {
        if (start < 1 || start > V) {
            cout << "Invalid starting vertex!" << endl;
            return;
        }

        bool* visited = new bool[V];
        for (int i = 0; i < V; ++i) {
            visited[i] = false;
        }

        Stack stack;
        stack.push(start-1);

        while (!stack.isEmpty()) {
            int v = stack.pop();

            if (!visited[v]) {
                visited[v] = true;
                cout << v + 1 << " ";

                Node* node = adj[v].head;
                while (node != nullptr) {
                    if (!visited[node->dest]) {
                        stack.push(node->dest);
                    }
                    node = node->next;
                }
            }
        }
        cout << endl;

        delete[] visited;
    }

    void BFS(int start) {
        if (start < 1 || start > V) {
            cout << "Invalid starting vertex!" << endl;
            return;
        }

        bool* visited = new bool[V];
        for (int i = 0; i < V; ++i) {
            visited[i] = false;
        }

        Queue queue;
        queue.enqueue(start-1);

        while (!queue.isEmpty()) {
            int v = queue.dequeue();

            if (!visited[v]) {
                visited[v] = true;
                cout << v + 1 << " ";

                Node* node = adj[v].head;
                while (node != nullptr) {
                    if (!visited[node->dest]) {
                        queue.enqueue(node->dest);
                    }
                    node = node->next;
                }
            }
        }
        cout << endl;

        delete[] visited;
    }

    void highestBandwidthPath(int start, int end) {
        // Adjust for 1-based index
        if (start < 1 || start > V || end < 1 || end > V) {
            cout << "Invalid start or end vertex!" << endl;
            return;
        }

        int* bandwidth = new int[V];
        bool* visited = new bool[V];
        int* predecessor = new int[V];

        for (int i = 0; i < V; ++i) {
            bandwidth[i] = 0;
            visited[i] = false;
            predecessor[i] = -1;
        }

        bandwidth[start-1] = INT_MAX;

        for (int i = 0; i < V - 1; ++i) {
            int max_bandwidth = 0;
            int u = -1;

            for (int v = 0; v < V; ++v) {
                if (!visited[v] && bandwidth[v] > max_bandwidth) {
                    max_bandwidth = bandwidth[v];
                    u = v;
                }
            }

            if (u == -1) break;

            visited[u] = true;

            Node* node = adj[u].head;
            while (node != nullptr) {
                if (!visited[node->dest] && min(bandwidth[u], node->bandwidth) > bandwidth[node->dest]) {
                    bandwidth[node->dest] = min(bandwidth[u], node->bandwidth);
                    predecessor[node->dest] = u;
                }
                node = node->next;
            }
        }

        if (bandwidth[end-1] == 0) {
            cout << "No path from " << start << " to " << end << endl;
        } else {
            cout << "Path from " << start << " to " << end << ": ";
            int current = end-1;
            Stack path;
            while (current != -1) {
                path.push(current);
                current = predecessor[current];
            }

            int max_bw = INT_MIN;
            int min_bw = INT_MAX;

            current = path.pop();
            cout << current + 1;
            int next = path.pop();
            while (next != -1) {
                Node* node = adj[current].head;
                while (node != nullptr) {
                    if (node->dest == next) {
                        if (node->bandwidth > max_bw) max_bw = node->bandwidth;
                        if (node->bandwidth < min_bw) min_bw = node->bandwidth;
                        break;
                    }
                    node = node->next;
                }
                cout << " -> " << next + 1;
                current = next;
                next = path.pop();
            }

            cout << endl;
            cout << "Maximum bandwidth on path: " << max_bw << endl;
            cout << "Minimum bandwidth on path: " << min_bw << endl;
        }

        delete[] bandwidth;
        delete[] visited;
        delete[] predecessor;
    }
};

// Helper function to draw text on the screen
void drawText(sf::RenderWindow &window, const string &text, int x, int y, int size = 24) {
    sf::Font font;
    font.loadFromFile("C:/Windows/Fonts/arial.ttf");
    sf::Text sfText;
    sfText.setFont(font);
    sfText.setString(text);
    sfText.setCharacterSize(size);
    sfText.setFillColor(sf::Color::White);
    sfText.setPosition(x, y);
    window.draw(sfText);
}

int getInput(int min, int max) {
    int input;
    while (true) {
        cout << "Enter a value between " << min << " and " << max << ": ";
        if (cin >> input && input >= min && input <= max) {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            break;
        } else {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please try again." << endl;
        }
    }
    return input;
}

int main() {
    int V;
    cout << "Enter the number of vertices: ";
    V = getInput(1, INT_MAX);

    Graph g(V);

    sf::RenderWindow window(sf::VideoMode(800, 600), "Graph Operations");

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();

            if (event.type == sf::Event::MouseButtonPressed) {
                if (event.mouseButton.button == sf::Mouse::Left) {
                    int mouseX = event.mouseButton.x;
                    int mouseY = event.mouseButton.y;

                    if (mouseX >= 50 && mouseX <= 200) {
                        if (mouseY >= 50 && mouseY <= 100) {
                            int u, v, bandwidth;
                            cout << "Enter the vertices (u, v) and bandwidth: ";
                            u = getInput(1, V);
                            v = getInput(1, V);
                            bandwidth = getInput(1, INT_MAX);
                            g.addEdge(u, v, bandwidth);
                        } else if (mouseY >= 150 && mouseY <= 200) {
                            int start;
                            cout << "Enter the starting vertex for DFS: ";
                            start = getInput(1, V);
                            g.DFS(start);
                        } else if (mouseY >= 250 && mouseY <= 300) {
                            int start;
                            cout << "Enter the starting vertex for BFS: ";
                            start = getInput(1, V);
                            g.BFS(start);
                        } else if (mouseY >= 350 && mouseY <= 400) {
                            int start, end;
                            cout << "Enter start vertex: ";
                            start = getInput(1, V);
                            cout << "Enter end vertex: ";
                            end = getInput(1, V);
                            g.highestBandwidthPath(start, end);
                        } else if (mouseY >= 450 && mouseY <= 500) {
                            window.close();
                        }
                    }
                }
            }
        }

        window.clear();

        drawText(window, "1. Add Edge", 50, 50);
        drawText(window, "2. Perform DFS", 50, 150);
        drawText(window, "3. Perform BFS", 50, 250);
        drawText(window, "4. Find Highest Bandwidth Path", 50, 350);
        drawText(window, "5. Exit", 50, 450);

        window.display();
    }

    return 0;
}
