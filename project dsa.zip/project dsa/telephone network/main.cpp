#include <iostream>
#include <climits>
#include <stdexcept>
using namespace std;

struct Node {
    int dest;
    int bandwidth;
    Node* next;
    Node(int d, int b){
        dest = d;
        bandwidth = b;
        next = nullptr;
    }
};

class LinkedList {
public:
    Node* head;
    LinkedList(){
        head = nullptr;
    }
    void addEdge(int dest, int bandwidth) {
        Node* newNode = new Node(dest, bandwidth);
        newNode->next = head;
        head = newNode;
    }
};

struct StackNode {
    int data;
    StackNode* next;
    StackNode(int d){
        data = d;
        next = nullptr;
    }
};

class Stack {
private:
    StackNode* top;

public:
    Stack(){
        top = nullptr;
    }
    void push(int data) {
        StackNode* newNode = new StackNode(data);
        newNode->next = top;
        top = newNode;
    }

    int pop() {
        if (isEmpty()) {
            return -1;
        }
        int data = top->data;
        StackNode* temp = top;
        top = top->next;
        delete temp;
        return data;
    }

    bool isEmpty() {
        return top == nullptr;
    }
};

struct QueueNode {
    int data;
    QueueNode* next;
    QueueNode(int d){
        data = d;
        next = nullptr;
    }
};

class Queue {
private:
    QueueNode *front, *rear;

public:
    Queue(){
        front = nullptr;
        rear = nullptr;
    }
    void enqueue(int data) {
        QueueNode* newNode = new QueueNode(data);
        if (rear) {
            rear->next = newNode;
        }
        rear = newNode;
        if (!front) {
            front = rear;
        }
    }

    int dequeue() {
        if (isEmpty()) {
            return -1;
        }
        int data = front->data;
        QueueNode* temp = front;
        front = front->next;
        if (!front) {
            rear = nullptr;
        }
        delete temp;
        return data;
    }

    bool isEmpty() {
        return front == nullptr;
    }
};

class Graph {
private:
    int V;
    LinkedList* adj;

public:
    Graph(int V) {
        this->V = V;
        adj = new LinkedList[V];
    }

    ~Graph() {
        delete[] adj;
    }

    void addEdge(int u, int v, int bandwidth) {
        // Adjust for 1-based index
        if (u >= 1 && u <= V && v >= 1 && v <= V) {
            adj[u-1].addEdge(v-1, bandwidth);
            adj[v-1].addEdge(u-1, bandwidth);
        } else {
            cout << "Invalid edge (" << u << ", " << v << ")!" << endl;
        }
    }
    void DFS(int start) {
        if (start < 1 || start > V) {
            cout << "Invalid starting vertex!" << endl;
            return;
        }

        bool* visited = new bool[V];
        for (int i = 0; i < V; ++i) {
            visited[i] = false;
        }

        Stack stack;
        stack.push(start-1);

        while (!stack.isEmpty()) {
            int v = stack.pop();

            if (!visited[v]) {
                visited[v] = true;
                cout << v + 1 << " ";

                Node* node = adj[v].head;
                while (node != nullptr) {
                    if (!visited[node->dest]) {
                        stack.push(node->dest);
                    }
                    node = node->next;
                }
            }
        }
        cout << endl;

        delete[] visited;
    }

    void BFS(int start) {
        if (start < 1 || start > V) {
            cout << "Invalid starting vertex!" << endl;
            return;
        }

        bool* visited = new bool[V];
        for (int i = 0; i < V; ++i) {
            visited[i] = false;
        }

        Queue queue;
        queue.enqueue(start-1);

        while (!queue.isEmpty()) {
            int v = queue.dequeue();

            if (!visited[v]) {
                visited[v] = true;
                cout << v + 1 << " ";

                Node* node = adj[v].head;
                while (node != nullptr) {
                    if (!visited[node->dest]) {
                        queue.enqueue(node->dest);
                    }
                    node = node->next;
                }
            }
        }
        cout << endl;

        delete[] visited;
    }

    void highestBandwidthPath(int start, int end) {
        // Adjust for 1-based index
        if (start < 1 || start > V || end < 1 || end > V) {
            cout << "Invalid start or end vertex!" << endl;
            return;
        }

        int* bandwidth = new int[V];
        bool* visited = new bool[V];
        int* predecessor = new int[V];

        for (int i = 0; i < V; ++i) {
            bandwidth[i] = 0;
            visited[i] = false;
            predecessor[i] = -1;
        }

        bandwidth[start-1] = INT_MAX;

        for (int i = 0; i < V - 1; ++i) {
            int max_bandwidth = 0;
            int u = -1;

            for (int v = 0; v < V; ++v) {
                if (!visited[v] && bandwidth[v] > max_bandwidth) {
                    max_bandwidth = bandwidth[v];
                    u = v;
                }
            }

            if (u == -1) break;

            visited[u] = true;

            Node* node = adj[u].head;
            while (node != nullptr) {
                if (!visited[node->dest] && min(bandwidth[u], node->bandwidth) > bandwidth[node->dest]) {
                    bandwidth[node->dest] = min(bandwidth[u], node->bandwidth);
                    predecessor[node->dest] = u;
                }
                node = node->next;
            }
        }

        if (bandwidth[end-1] == 0) {
            cout << "No path from " << start << " to " << end << endl;
        } else {
            cout << "Path from " << start << " to " << end << ": ";
            int current = end-1;
            Stack path;
            while (current != -1) {
                path.push(current);
                current = predecessor[current];
            }

            int max_bw = INT_MIN;
            int min_bw = INT_MAX;

            current = path.pop();
            cout << current + 1;
            int next = path.pop();
            while (next != -1) {
                Node* node = adj[current].head;
                while (node != nullptr) {
                    if (node->dest == next) {
                        if (node->bandwidth > max_bw) max_bw = node->bandwidth;
                        if (node->bandwidth < min_bw) min_bw = node->bandwidth;
                        break;
                    }
                    node = node->next;
                }
                cout << " -> " << next + 1;
                current = next;
                next = path.pop();
            }

            cout << endl;
            cout << "Maximum bandwidth on path: " << max_bw << endl;
            cout << "Minimum bandwidth on path: " << min_bw << endl;
        }

        delete[] bandwidth;
        delete[] visited;
        delete[] predecessor;
    }
};

int getInput(int min, int max) {
    int input;
    string line;
    while (true) {
        try {
            getline(cin, line);
            if (line.empty()) {
                throw invalid_argument("Input cannot be empty. Please enter a valid integer.");
            }
            input = stoi(line);
            if (input < min || input > max) {
                throw out_of_range("Input out of range. Please enter a value between " + to_string(min) + " and " + to_string(max) + ".");
            }
            break;
        } catch (const invalid_argument& e) {
            cout << e.what() << endl;
        } catch (const out_of_range& e) {
            cout << e.what() << endl;
        }
    }
    return input;
}

int main() {
    int V;
    cout << "Enter the number of vertices: ";
    V = getInput(1, INT_MAX);

    Graph g(V);

    while (true) {
        cout << "Menu:\n";
        cout << "1. Add Edge\n";
        cout << "2. Perform DFS\n";
        cout << "3. Perform BFS\n";
        cout << "4. Find Highest Bandwidth Path\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        int choice = getInput(1, 5);

        switch (choice) {
            case 1: {
                int u, v, bandwidth;
                cout << "Enter the vertices (u, v) and bandwidth: ";
                u = getInput(1, V);
                v = getInput(1, V);
                cout << "Enter bandwidth: ";
                bandwidth = getInput(1, INT_MAX);
                g.addEdge(u, v, bandwidth);
                break;
            }
            case 2: {
                int start;
                cout << "Enter the starting vertex for DFS: ";
                start = getInput(1, V);
                g.DFS(start);
                break;
            }
            case 3: {
                int start;
                cout << "Enter the starting vertex for BFS: ";
                start = getInput(1, V);
                g.BFS(start);
                break;
            }
            case 4: {
                int start, end;
                cout << "Enter start vertex: ";
                start = getInput(1, V);
                cout << "Enter end vertex: ";
                end = getInput(1, V);
                g.highestBandwidthPath(start, end);
                break;
            }
            case 5:
                return 0;
            default:
                cout << "Invalid choice!" << endl;
        }
    }

    return 0;
}